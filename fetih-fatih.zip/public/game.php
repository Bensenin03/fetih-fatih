<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Kullanıcının şehir verilerini çek
$stmt = $pdo->prepare("SELECT wood, stone, iron, last_update FROM cities WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$city = $stmt->fetch();

if (!$city) {
    // Şehir yoksa oluştur
    $stmt = $pdo->prepare("INSERT INTO cities (user_id, wood, stone, iron, last_update) VALUES (?, 100, 100, 100, NOW())");
    $stmt->execute([$_SESSION['user_id']]);
    $wood = 100;
    $stone = 100;
    $iron = 100;
    $last_update = new DateTime();
} else {
    $wood = $city['wood'];
    $stone = $city['stone'];
    $iron = $city['iron'];
    $last_update = new DateTime($city['last_update']);
}

// Zaman farkını hesapla ve kaynak üretimini güncelle
$now = new DateTime();
$diff = $now->getTimestamp() - $last_update->getTimestamp();
$seconds = $diff > 0 ? $diff : 0;

// Basit üretim hızı (her saniye 0.1 kaynak)
$production_rate = 0.1;
$wood += $production_rate * $seconds;
$stone += $production_rate * $seconds;
$iron += $production_rate * $seconds;

// Veritabanını güncelle
$stmt = $pdo->prepare("UPDATE cities SET wood = ?, stone = ?, iron = ?, last_update = NOW() WHERE user_id = ?");
$stmt->execute([floor($wood), floor($stone), floor($iron), $_SESSION['user_id']]);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Fetih: Fatih - Şehir</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Fetih: Fatih - Şehir Ekranı</h1>
        <p>Odun: <?= floor($wood) ?></p>
        <p>Taş: <?= floor($stone) ?></p>
        <p>Demir: <?= floor($iron) ?></p>
        <p><a href="logout.php">Çıkış Yap</a></p>
    </div>
</body>
</html>
