<?php
session_start();
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Basit doğrulama ve hash
    if(strlen($username) < 3 || strlen($password) < 3) {
        $error = "Kullanıcı adı ve şifre en az 3 karakter olmalı.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        if ($stmt->execute([$username, $hash])) {
            header('Location: index.php');
            exit;
        } else {
            $error = "Kayıt başarısız, kullanıcı adı zaten var olabilir.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Fetih: Fatih - Kayıt</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Kayıt Ol</h1>
        <?php if(isset($error)): ?>
            <p style="color:red;"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <form action="" method="POST">
            <input type="text" name="username" placeholder="Kullanıcı Adı" required><br>
            <input type="password" name="password" placeholder="Şifre" required><br>
            <button type="submit">Kayıt Ol</button>
        </form>
        <p>Zaten hesabın var mı? <a href="index.php">Giriş Yap</a></p>
    </div>
</body>
</html>
