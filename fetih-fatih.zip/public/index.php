<?php
session_start();
if(isset($_SESSION['user_id'])) {
    header('Location: game.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Fetih: Fatih - Giriş</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Fetih: Fatih - Giriş</h1>
        <form action="login.php" method="POST">
            <input type="text" name="username" placeholder="Kullanıcı Adı" required><br>
            <input type="password" name="password" placeholder="Şifre" required><br>
            <button type="submit">Giriş Yap</button>
        </form>
        <p>Hesabın yok mu? <a href="register.php">Kayıt Ol</a></p>
    </div>
</body>
</html>
